//Ryan Barrett
//interface with incrementable and getValue methods
public interface Incrementable {
	public void incrementable();
	public int getValue();
}
