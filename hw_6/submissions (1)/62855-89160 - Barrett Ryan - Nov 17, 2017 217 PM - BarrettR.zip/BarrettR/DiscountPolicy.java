//Ryan Barrett
//interface with computeDiscount method...
public abstract class DiscountPolicy {
	public abstract double computeDiscount(int quantity, double itemCost);
}