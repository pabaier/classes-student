
/**
 * Interface for incrementing 
 *
 * Jonathan Rabiu
 * 
 */
public interface Incrementable
{
   void increment();
   
   int getValue();
}
