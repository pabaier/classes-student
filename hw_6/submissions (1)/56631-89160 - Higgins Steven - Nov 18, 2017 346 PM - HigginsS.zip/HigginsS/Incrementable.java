
/**
 * Write a description of interface Incrementable here.
 *
 * Steven Higgins
 * 
 */
public interface Incrementable

{
    public void increment();
    public int getValue();
}
