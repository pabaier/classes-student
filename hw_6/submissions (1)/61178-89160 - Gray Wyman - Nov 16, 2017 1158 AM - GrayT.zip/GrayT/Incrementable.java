/*Tyler Gray
 * Interface for class that increments a value
 */
public interface Incrementable {
		
	public void increment();
	
	public int getValue();
}
