
/**
 * Ariel Robinson
 *
 * the interface that Sequential and Random incrementer uses
 */
public interface Incrementable
{
    public void increment();

    public int getValue();
}
