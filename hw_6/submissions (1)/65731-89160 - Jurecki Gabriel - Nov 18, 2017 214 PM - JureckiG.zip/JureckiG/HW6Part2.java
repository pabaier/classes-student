//Gabe Jurecki
public class HW6Part2 {
    public static void main(String[] args) {
        Incrementable sequential = new SequentialIncrementer(5);
        Incrementable random = new RandomIncrementer();
    }
}
