public interface Incrementable {
    public int increment(int x);
    public int getValue(int y);

}
