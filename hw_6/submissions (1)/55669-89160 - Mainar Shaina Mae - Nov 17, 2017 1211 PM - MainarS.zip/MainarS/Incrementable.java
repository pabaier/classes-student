public interface Incrementable {
    void increment (int val);
    int getValue();

}
