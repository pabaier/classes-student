//@Readme file:
//I discussed this homework assignment with: CSCI tutors (Daniel & Anthony), Paul B. & Kyle W. 
//for part 2 I went on java’s oracle website to re-read how to import and use random.