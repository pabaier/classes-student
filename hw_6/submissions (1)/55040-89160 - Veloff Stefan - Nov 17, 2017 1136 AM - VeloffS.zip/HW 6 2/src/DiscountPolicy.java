//@author: Stefan Veloff;
//CSCI 221:HW6Part1:
//This is the abstract class DiscountPolicy{}
//I discussed this homework assignment with: CSCI tutors (Daniel & Anthony M.), Paul B. & Kyle W. 


//Abstract class:
public abstract class DiscountPolicy {
	
	abstract double computeDiscount(int quantity, double itemCost);

}
