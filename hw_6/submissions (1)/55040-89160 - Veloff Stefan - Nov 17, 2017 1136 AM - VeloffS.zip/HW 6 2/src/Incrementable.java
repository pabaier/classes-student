//@author: Stefan Veloff 
//CSCI 221:HW6Part2:
//This is an incremental interface program:
//I discussed this homework assignment with: CSCI tutors (Daniel & Anthony), Paul B. & Kyle W. 


//Incremental interface:
public interface Incrementable {

	//increment method:
	public void increment();
	//getValue method:
	public int getValue();	
}
