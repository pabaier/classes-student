
/**
 * interface incrementable is derived in other classes.
 *
 * @Dustin Cragg
 * @11/17/2017
 */
public interface Incrementable
{
   void Increment();
   int getValue();
  
}
