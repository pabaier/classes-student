
/**
 * Create a inferface in which class contains a method signature
 *
 * Julie Yib 
 * 
 */
public interface Incrementable
{
    public void increment(int inc);
        
}
