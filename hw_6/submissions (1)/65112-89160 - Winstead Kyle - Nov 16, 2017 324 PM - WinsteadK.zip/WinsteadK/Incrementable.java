/*
 * Name: Kyle Winstead
 */
public interface Incrementable {

	public void increment();
	
	public double getValue();	
}
