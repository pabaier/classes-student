
/**
 * Write a description of class Lab4 here.
 *
 * Your name

 */

public class Lab4
{    
    public static void main(String [] args){
        double [] data = {3.2, 4.5, 10.4, -1.2, -2.3, 0.1, 6.7, 0.2, 12.2, -3.3};
        double min = 0.0; // change this to a call to minimum method
        double max = 0.0; // change this to a call to maximum method
        double mean = 0.0; // change this to a call to average method
        double var = 0.0; // change this to a call to variance method
        System.out.printf("Min = %.3f, Max = %.3f, Mean = %.3f, Variance = %.3f",
              min, max, mean, var); 
    }
    
    // Finds and returns the minimum value in
    // an array of doubles
    public static double minimum (double [] x){
          
        return 0.0;
        
    }
    
    // Add other methods here.
   
}
