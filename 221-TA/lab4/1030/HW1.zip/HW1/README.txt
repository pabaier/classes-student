Gina Cordoba and I worked together on this homework assignment. She gave me the ida of searching Regex, while
gave her the idea of parsing.